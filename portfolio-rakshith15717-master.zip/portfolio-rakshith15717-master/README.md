COMP6200 Data Science Portfolio 
===

This repository will hold your portfolio projects for this semester. You should customise this README.md file
to document your own work - add your name and details and describe what you've done.  This will be displayed
on your Github page.

Portfolio projects
Portfolio 1:
Analysis of CSV data for cycling 
Here we are analyzing the aspects which will affect the cycle rider capacity
We have taken two datasets and combined it for better visualization
We have analyzed the data comparing all the variables to give better suggestions for rider to maintain their health

Portfolio 2:
We have taken the data for the ongoing pandemaic of corona virus(COVID-19)
We have cleaned the data according to our requirments
First we compared data from few countries and also did visualization for it so we can get better understanding
Next we are building a predictive model 
we have trained the data for a specific country
So the model output has an MSE of around 0.4
Hence the model was validated

Portfolio 3:
First we read the data
Then I have built 3 predictive models to classify the books into one of the 5 target genres.
We have separated the text of summary using stopwords and built a model according to it
Then we have used CountVectorizer whichTransforms text into a sparse matrix of n-gram counts.
and
TfidfTransformer which Performs the TF-IDF transformation from a provided matrix of counts.
Then I have trained the data on Linear SVC, Multinomial Naives bayes and logistic Regression
and I compared all the three models and I got the best output for logistic regression with around 0.69 accuracy
